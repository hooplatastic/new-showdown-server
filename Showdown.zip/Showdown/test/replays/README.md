Replays of battles created by tests are stored in this directory via the `common.saveReplay` function.
