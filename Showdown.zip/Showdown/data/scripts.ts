export const Scripts: BattleScriptsData = {
	gen: 8,
};
