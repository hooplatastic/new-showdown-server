Stadium 2
====================

This mod inherits from gen 2, which inherits from gen 3, and then applies the Stadium changes upon the gen 2 engine.

List of major changes:

 * Sleep lasts between 1 and 4 turns.
 * Belly Drum boosting your attack by +2 if you are below 50% health was fixed.
 * Stat overflow glitches were fixed.
 * Status ailments are ignored when recalculating stats due to Haze, stat increases, or stat decreases.
 * Perish Song and Destiny Bond fail when used by the last Pokemon on a team.
 * Recoil moves do not damage the user if they are used by the last Pokemon on a team and knock out the opponents last Pokemon.
 * If the last pokemon on a players team uses Self Destruct or Explosion, the player automatically loses (Self KO Clause).
